// Professional Profile Page JavaScript
// Author: Abu Bakar - WordPress Web Developer

document.addEventListener('DOMContentLoaded', function() {
    
    // Initialize page animations and interactions
    initializePageAnimations();
    setupLinkTracking();
    handleImageError();
    addKeyboardNavigation();
    setupScrollEffects();
    
    console.log('Professional Profile Page Loaded Successfully');
});

/**
 * Initialize smooth animations for page elements
 */
function initializePageAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe all profile links for staggered animation
    const profileLinks = document.querySelectorAll('.profile-link');
    profileLinks.forEach((link, index) => {
        link.style.opacity = '0';
        link.style.transform = 'translateY(20px)';
        link.style.transition = `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`;
        observer.observe(link);
    });
}

/**
 * Setup click tracking for analytics (if needed)
 */
function setupLinkTracking() {
    const profileLinks = document.querySelectorAll('.profile-link, .social-icon');
    
    profileLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const linkText = this.querySelector('.link-text')?.textContent || 
                            this.getAttribute('title') || 
                            'Unknown';
            
            // Track link clicks (you can integrate with Google Analytics here)
            console.log(`Profile link clicked: ${linkText}`);
            
            // Add click animation
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    });
}

/**
 * Handle profile image loading errors
 */
function handleImageError() {
    const profileImage = document.querySelector('.profile-image');
    
    if (profileImage) {
        profileImage.addEventListener('error', function() {
            // Create a fallback with initials
            this.style.display = 'none';
            
            const fallbackDiv = document.createElement('div');
            fallbackDiv.className = 'profile-image-fallback';
            fallbackDiv.textContent = 'AB'; // Abu Bakar initials
            fallbackDiv.style.cssText = `
                width: 120px;
                height: 120px;
                border-radius: 50%;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 2rem;
                font-weight: 600;
                color: white;
                border: 4px solid rgba(255, 255, 255, 0.2);
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            `;
            
            this.parentNode.appendChild(fallbackDiv);
        });
    }
}

/**
 * Add keyboard navigation support
 */
function addKeyboardNavigation() {
    const focusableElements = document.querySelectorAll('.profile-link, .social-icon');
    
    focusableElements.forEach(element => {
        element.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    });
}

/**
 * Setup scroll effects for better UX
 */
function setupScrollEffects() {
    let lastScrollTop = 0;
    const container = document.querySelector('.container');
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // Add scroll-based parallax effect (subtle)
        if (container) {
            const scrollPercent = scrollTop / (document.body.scrollHeight - window.innerHeight);
            container.style.transform = `translateY(${scrollPercent * 10}px)`;
        }
        
        lastScrollTop = scrollTop;
    }, { passive: true });
}

/**
 * Utility function to copy email to clipboard
 */
function copyEmailToClipboard() {
    // Get email from the email link
    const emailLink = document.querySelector('.profile-link.email');
    if (emailLink) {
        const email = emailLink.href.replace('mailto:', '');
        
        navigator.clipboard.writeText(email).then(() => {
            showNotification('Email copied to clipboard!');
        }).catch(() => {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = email;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            showNotification('Email copied to clipboard!');
        });
    }
}

/**
 * Show notification to user
 */
function showNotification(message) {
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(37, 211, 102, 0.9);
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        z-index: 1000;
        font-size: 0.9rem;
        backdrop-filter: blur(10px);
        animation: slideIn 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out forwards';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

/**
 * Add CSS animations for notifications
 */
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

/**
 * Enhanced link interaction effects
 */
function enhanceLinkInteractions() {
    const profileLinks = document.querySelectorAll('.profile-link');
    
    profileLinks.forEach(link => {
        // Add ripple effect on click
        link.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 50%;
                transform: scale(0);
                animation: ripple 0.6s ease-out;
                pointer-events: none;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
}

// Add ripple animation CSS
const rippleStyle = document.createElement('style');
rippleStyle.textContent = `
    @keyframes ripple {
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
`;
document.head.appendChild(rippleStyle);

// Initialize enhanced interactions
enhanceLinkInteractions();

/**
 * Add double-click functionality to email for copying
 */
document.addEventListener('DOMContentLoaded', function() {
    const emailLink = document.querySelector('.profile-link.email');
    if (emailLink) {
        emailLink.addEventListener('dblclick', function(e) {
            e.preventDefault();
            copyEmailToClipboard();
        });
        
        // Add tooltip for double-click hint
        emailLink.setAttribute('title', 'Double-click to copy email');
    }
});
